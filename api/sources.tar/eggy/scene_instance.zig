//! `SceneInstance`: an entity that stands for a whole scene file, as an instanced scene does in
//! Godot. The scene's entities are made under it, from the file, and they aren't saved with the
//! scene the instance is in, only the instance itself, so a change to the file shows wherever
//! it is instanced. A built-in component, whose entities `scene_instances.zig` makes and remakes,
//! in the editor and the runtime.
//!
//!     .{ .type = "SceneInstance", .owner = "eggy", .fields = .{ .scene = "000000000000002a" } }
const std = @import("std");
const components = @import("components.zig");
const AssetRef = @import("refs.zig").AssetRef;
const Transform = @import("transform.zig").Transform;

pub const SceneInstance = struct {
    /// Marks it in the editor (nf-md-package_variant_closed).
    pub const icon = "\u{f03d7}";
    /// Its entities go where its `Transform` puts them.
    pub const dependencies = .{Transform};

    /// The scene file made under it; none (no entities) when empty.
    scene: AssetRef(.scene) = .{},
};

/// Where `SceneInstance` is among `types`, if it is there.
/// Matches both the public name and the `"eggy"` owner; returns an index, not an ECS type ID.
///
/// ```zig
/// const index = typeIndex(registry_infos) orelse return error.SceneInstancesUnavailable;
/// ```
pub fn typeIndex(types: []const components.Info) ?usize {
    for (types, 0..) |info, i| {
        if (std.mem.eql(u8, info.name, "SceneInstance") and std.mem.eql(u8, info.owner, "eggy")) return i;
    }
    return null;
}

test "the instance is found among a registry's types" {
    const Registry = components.Registry(&.{ Transform, SceneInstance }, &.{ "eggy", "eggy" });
    try std.testing.expectEqual(@as(?usize, 1), typeIndex(Registry.infos));
    try std.testing.expectEqual(@as(?usize, null), typeIndex(Registry.infos[0..1]));
}
